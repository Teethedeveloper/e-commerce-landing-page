// Import necessary libraries
import { useMemo, useEffect, useState, useCallback } from "https://esm.sh/react";
import { createSlice, createAsyncThunk, configureStore } from "https://esm.sh/@reduxjs/toolkit";
import { Provider, useDispatch, useSelector } from "https://esm.sh/react-redux";
import React from "https://esm.sh/react";
import ReactDOM from "https://esm.sh/react-dom";
import { createRoot } from "https://esm.sh/react-dom/client";

// Async thunk to fetch products
const fetchProducts = createAsyncThunk('products/fetchProducts', async () => {
  try {
    const response = await fetch("https://fakestoreapi.com/products");
    if (!response.ok) throw new Error("Failed to fetch products.");
    return response.json();
  } catch (error) {
    throw new Error(error.message);
  }
});

const fetchCategoryProducts = createAsyncThunk('products/fetchCategoryProducts', async (category) => {
  try {
    const response = await fetch(`https://fakestoreapi.com/products/category/${category}`);
    if (!response.ok) throw new Error("Failed to fetch category products.");
    return response.json();
  } catch (error) {
    throw new Error(error.message);
  }
});

const cartSlice = createSlice({
  name: "cart",
  initialState: { items: [], error: null, discount: 0, promoCode: null },
  reducers: {
    addToCart: (state, action) => {
      const existingItem = state.items.find(item => item.id === action.payload.id);
      if (existingItem) {
        existingItem.quantity += 1;
      } else {
        state.items.push({ ...action.payload, quantity: 1 });
      }
      
      state.error = null;
    },
    removeFromCart: (state, action) => {
      state.items = state.items.filter(item => item.id !== action.payload);
      state.error = null;
    },
    updateQuantity: (state, action) => {
      const item = state.items.find(item => item.id === action.payload.id);
      if (item) item.quantity = action.payload.quantity;
      state.error = null;
    },
    applyDiscount: (state, action) => {
      if (!state.promoCode) {
        state.discount = action.payload.discount;
        state.promoCode = action.payload.code;
      }
    },
    removePromoCode: (state) => {
      state.discount = 0;
      state.promoCode = null;
    }
  }
});

const wishlistSlice = createSlice({
  name: "wishlist",
  initialState: { items: [],error : null},
  reducers: {
    addToWishlist: (state, action) => {
      if (state.items.length >= 3) {
        state.error = "Wishlist is full. Remove an item to add a new one.";
      } else {
        state.items.push(action.payload);
        state.error = null;
      }
    },
    removeFromWishlist: (state, action) => {
      if (state.items.length === 0) {
        state.error = "Wishlist is empty"
      } else {
        state.items = state.items.filter((item) => item.id !== action.payload);
        state.error = null;
      }
    },
  },
});

// Product Slice
const productSlice = createSlice({
  name: "products",
  initialState: { products: [], filtered: [], filter: "all", search: "", currentPage: 1, totalPages: 0, status: 'idle', error: null },
  reducers: {
    setFilter: (state, action) => {
  state.filter = action.payload;
  state.filtered = action.payload === "all"
    ? state.products
    : state.products.filter(product => product.category === action.payload);
  state.currentPage = 1;
},
    setSearch: (state, action) => {
      state.search = action.payload;
      state.filtered = state.products.filter(product =>
        product.title.toLowerCase().includes(action.payload.toLowerCase())
      );
      state.currentPage = 1;  // Reset to first page after search
    },
    setPage: (state, action) => {
      state.currentPage = action.payload;
    }
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchProducts.pending, (state) => {
        state.status = 'loading';
      })
      .addCase(fetchProducts.fulfilled, (state, action) => {
        state.status = 'succeeded';
        state.products = action.payload;
        state.filtered = action.payload;
        state.totalPages = Math.ceil(action.payload.length / 6);
      })
      .addCase(fetchProducts.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action.error.message;
      });
  }
});

// Store Setup
const store = configureStore({
  reducer: {
    cart: cartSlice.reducer,
    products: productSlice.reducer,
    wishlist: wishlistSlice.reducer
  }
});

const Navbar = () => {
  // Use useRef to attach ScrollSpy
  const navRef = React.useRef(null);

  useEffect(() => {
  if (navRef.current) {
    new bootstrap.ScrollSpy(navRef.current, {
      target: "#navbarNav",
      offset: 50,
    });
  }
}, []);
;

  return (
    <nav
      ref={navRef}
      className="navbar navbar-expand-lg fixed-top px-5"
      style={{ backgroundColor: "#d065e6" }}
      id="navbarNav"
    >
      <span className="navbar-brand text-white">
        DOPAMINE99 <i className="fa-regular fa-face-laugh-beam"></i>
      </span>
      <button
        className="navbar-toggler"
        type="button"
        data-bs-toggle="collapse"
        data-bs-target="#navbarNav"
        aria-controls="navbarNav"
        aria-expanded="false"
        aria-label="Toggle navigation"
      >
        <span className="navbar-toggler-icon"></span>
      </button>
      <div className="collapse navbar-collapse" id="navbarNav">
        <ul className="navbar-nav ms-auto">
          <li className="nav-item">
            <a className="nav-link text-white" href="#shop">
              Shop
            </a>
          </li>
          <li className="nav-item">
            <a className="nav-link text-white" href="#about">
              About
            </a>
          </li>
          <li className="nav-item">
            <a className="nav-link text-white" href="#deliveries">
              Deliveries
            </a>
          </li>
          <li className="nav-item">
            <a className="nav-link text-white" href="#terms">
              T&Cs
            </a>
          </li>
        </ul>
      </div>
    </nav>
  );
};

// Components
const ProductCard = React.memo(({ product, onAddToCart, onAddToWishlist }) => (
  <div className="col-md-2 mb-4">
    <div className="card p-3 product-card">
      <img
        src={product.image}
        alt={product.title}
        className="card-img-top product-image"
        loading="lazy"
      />
      <h5 className="card-title">{product.title}</h5>
      <p className="card-text">${product.price}</p>

      <div className="product-description-container">
        <p className="card-text product-description">{product.description}</p>
      </div>
      <button className="btn btn-primary" onClick={() => onAddToCart(product)}>Add to Cart</button>
      <button className="btn btn-outline-danger ms-2" onClick={() => onAddToWishlist(product)}>
        <i className="fa fa-heart"></i> Wishlist
      </button>
    </div>
  </div>
))

const ProductList = () => {
  const dispatch = useDispatch();
  const { filtered: products, filter, search, currentPage, status, error } = useSelector(state => state.products);
  const [debouncedSearch, setDebouncedSearch] = useState(search);

  // Debounce the search input
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSearch(search);
    }, 500);

    return () => clearTimeout(timer); // Cleanup the timer on component unmount
  }, [search]);

  useEffect(() => {
    if (filter === "all") {
      dispatch(fetchProducts());
    } else {
      dispatch(fetchCategoryProducts(filter));
    }
  }, [dispatch, filter]);

  useEffect(() => {
    if (debouncedSearch) {
      dispatch(productSlice.actions.setSearch(debouncedSearch));
    }
  }, [debouncedSearch, dispatch]);

  const filteredProducts = useMemo(() => {
    return products
      .filter(product => product.category === filter || filter === 'all')
      .slice((currentPage - 1) * 6, currentPage * 6);
  }, [products, currentPage, filter]);

  const onAddToCart = useCallback((product) => {
  dispatch(cartSlice.actions.addToCart(product));
}, [dispatch]);

const onAddToWishlist = useCallback((product) => {
  dispatch(wishlistSlice.actions.addToWishlist(product));
}, [dispatch]);

  if (status === 'loading') {
    return (
      <div id="shop" className="container mt-3">
        <h2>Shop here!</h2>
        <div className="d-flex justify-content-center">
          <div className="spinner-border text-primary" role="status">
            <span className="sr-only">Loading...</span>
          </div>
        </div>
      </div>
    );
  }

  if (status === 'failed') return <div>Error: {error}</div>;

  return (
    <div id="shop" className="container mt-3">
      <h2>Shop here!</h2>

      {/* Search Input */}
      <div className="search-filter-container mb-3">
        <input
          type="text"
          className="form-control search-input"
          placeholder="Search Products..."
          value={search}
          onChange={e => dispatch(productSlice.actions.setSearch(e.target.value))}
        />
      </div>

      {/* Filter Dropdown */}
      <div className="search-filter-container mb-3">
        <select
          className="form-select filter-select"
          value={filter}
          onChange={e => dispatch(productSlice.actions.setFilter(e.target.value))}
        >
          <option value="all">All</option>
          <option value="jewelery">Jewellery</option>
          <option value="electronics">Electronics</option>
          <option value="men's clothing">Men's Clothing</option>
          <option value="women's clothing">Women's Clothing</option>
        </select>
      </div>

      {/* Product Cards */}
      <div className="row">
        {filteredProducts.map(product => (
          <ProductCard
            key={product.id}
            product={product}
            onAddToCart={product => dispatch(cartSlice.actions.addToCart(product))}
            onAddToWishlist={onAddToWishlist}  // Pass the addToWishlist function here
          />
        ))}
      </div>

      {/* Pagination */}
      <div className="pagination">
        {currentPage > 1 && (
          <button
            className="btn btn-link pagination-btn"
            onClick={() => dispatch(productSlice.actions.setPage(currentPage - 1))}
          >
            <i className="fa fa-arrow-circle-left" aria-hidden="true"></i>
          </button>
        )}

        {Array.from({ length: Math.ceil(products.filter(p => p.category === filter || filter === 'all').length / 6) }, (_, i) => (
          <button
            key={i}
            className="btn btn-link pagination-btn"
            onClick={() => dispatch(productSlice.actions.setPage(i + 1))}
          >
            {i + 1}
          </button>
        ))}

        {currentPage < Math.ceil(products.filter(p => p.category === filter || filter === 'all').length / 6) && (
          <button
            className="btn btn-link pagination-btn"
            onClick={() => dispatch(productSlice.actions.setPage(currentPage + 1))}
          >
            <i className="fa fa-arrow-circle-right" aria-hidden="true"></i>
          </button>
        )}
      </div>
    </div>
  );
};

const Cart = () => {
  const dispatch = useDispatch();
  const cartItems = useSelector(state => state.cart.items);
  const discount = useSelector(state => state.cart.discount);
  const promoCode = useSelector(state => state.cart.promoCode);
  const [enteredPromoCode, setEnteredPromoCode] = useState("");
  const [promoMessage, setPromoMessage] = useState("");

  const validPromoCodes = {
    "SAVE10": 0.10, // 10% discount
    "SAVE20": 0.20, // 20% discount
    "FREE5": 0.05   // 5% discount
  };

  const applyPromoCode = () => {
    if (validPromoCodes[enteredPromoCode] && !promoCode) {
      dispatch(cartSlice.actions.applyDiscount({
        discount: validPromoCodes[enteredPromoCode],
        code: enteredPromoCode
      }));
      setPromoMessage(`Promo Code ${enteredPromoCode} applied!`); // Set success message
    } else {
      setPromoMessage("Invalid promo code or promo code already applied.");
    }
  };

  const removePromoCode = () => {
    dispatch(cartSlice.actions.removePromoCode());
    setEnteredPromoCode(""); // Clear the input field
    setPromoMessage("");
  };

  const getTotalPrice = () => {
    return cartItems.reduce((total, item) => total + item.price * item.quantity, 0) * (1 - discount);
  };

  return (
    <div id="cart" className="container mt-3">
      <h2>Cart <i className="fa fa-shopping-cart" aria-hidden="true"></i></h2>

      {cartItems.length === 0 ? (
        <p>No items in the cart.</p>
      ) : (
        <div>
          <div className="cart-items">
            {cartItems.map(item => (
              <div key={item.id} className="cart-item">
                <p>{item.title} x {item.quantity}</p>
                <p>${item.price * item.quantity}</p>
                <button className="btn btn-danger" onClick={() => dispatch(cartSlice.actions.removeFromCart(item.id))}>
                  Remove
                </button>
              </div>
            ))}
          </div>

          <div className="discount-section">
            <input
              type="text"
              placeholder="Enter Promo Code"
              value={enteredPromoCode}
              onChange={e => setEnteredPromoCode(e.target.value)}
            />
            {!promoCode && (
              <button className="btn btn-primary" onClick={applyPromoCode}>
                Apply Promo Code
              </button>
            )}
            {promoCode && <button className="btn btn-danger" onClick={removePromoCode}>Remove Promo Code</button>}
            {/* Display promo message */}
            {promoMessage && (
              <p className={`promo-message ${promoMessage.includes("successfully") ? "success" : "error"}`}>
                {promoMessage}
              </p>
            )}
          </div>

          <h3>Total Price: ${getTotalPrice().toFixed(2)}</h3>
        </div>
      )}
    </div>
  );
};

const WishlistModal = ({ show, handleClose }) => {
  const wishlistItems = useSelector((state) => state.wishlist.items);
  const wishlistError = useSelector((state) => state.wishlist.error);
  const dispatch = useDispatch();

  const handleAddToCart = (item) => {
    // Dispatch the addToCart action to add the item to the cart
    dispatch(cartSlice.actions.addToCart(item));
    // Dispatch the removeFromWishlist action to remove the item from the wishlist
    dispatch(wishlistSlice.actions.removeFromWishlist(item.id));
  };
  
  const handleRemoveFromWishlist = (item) => {
    dispatch(wishlistSlice.actions.removeFromWishlist(item.id)); // Correctly dispatching the action
  };

  return (
    <div className={`modal fade ${show ? "show d-block" : "d-none"}`} tabIndex="-1">
      <div className="modal-dialog">
        <div className="modal-content">
          <div className="modal-header">
            <h5 className="modal-title">Your Wishlist</h5>
            <button type="button" className="btn-close" onClick={handleClose}></button>
          </div>
          <div className="modal-body">
            {wishlistError && <p className="alert alert-danger">{wishlistError}</p>}
            {wishlistItems.length === 0 ? (
              <p>Your wishlist is empty.</p>
            ) : (
              <ul className="list-group">
                {wishlistItems.map((item) => (
                  <li key={item.id} className="list-group-item d-flex justify-content-between align-items-center">
                    <span>{item.title}</span>
                    <div>
                      <button 
                        className="btn btn-success btn-sm me-2" 
                        onClick={() => handleAddToCart(item)} 
                        aria-label={`Add ${item.title} to cart`}
                      >Add to Cart
                      </button>
                      <button 
                        className="btn btn-danger btn-sm" 
                        onClick={() => handleRemoveFromWishlist(item)} 
                        aria-label={`Remove ${item.title} from wishlist`}
                      >
                        Remove
                      </button>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>
          <div className="modal-footer">
            <button className="btn btn-secondary" onClick={handleClose}>
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

const WishlistButton = () => {
  const [showModal, setShowModal] = useState(false);

  return (
    <div class="center-button">
      <button className="btn btn-outline-danger" onClick={() => setShowModal(true)}>
        <i className="fa fa-heart"></i> View Wishlist
      </button>
      <WishlistModal show={showModal} handleClose={() => setShowModal(false)} />
    </div>
  );
};

const About = () => (
  <div id="about" className="container mt-3">
    <h2>About</h2>
    <p>At Dopamine99, we believe that fashion is more than just clothes; it's an expression of individuality. Our carefully curated collection of clothing and jewellery is designed to help you feel confident and stylish, whether you're dressing for a special occasion or everyday wear.</p>

    <h3>Our Story</h3>
    <p>Founded with a passion for quality and creativity, Dopamine99 brings together timeless clothing pieces and stunning jewellery designs to elevate your wardrobe. From casual wear to elegant evening attire, we’ve got something for everyone. Our jewellery collection adds that perfect touch of sparkle to any outfit, whether you're looking for delicate pieces or statement accessories.</p>

    <h3>What We Offer</h3>
    <ul>
      <li><strong>Clothing:</strong> Trendy, comfortable, and versatile pieces that cater to all occasions.</li>
      <li><strong>Jewellery:</strong> Exquisite designs that elevate your personal style.</li>
      <li><strong>Personalized service:</strong> Dedicated to finding the perfect match for your needs.</li>
    </ul>

    <h3>Our Mission</h3>
    <p>We aim to provide high-quality products at affordable prices, all while supporting ethical practices and sustainable sourcing. Our team is committed to delivering an exceptional shopping experience and helping you find the perfect pieces that align with your style and values.</p>

    <h3>Sustainability</h3>
    <p>We are committed to sustainability and strive to reduce our environmental impact through eco-friendly packaging and sustainable materials. Our goal is to provide beautiful products that you can feel good about purchasing.</p>

    <h3>Why Choose Us?</h3>
    <p>We offer a wide variety of stylish, high-quality clothing and jewelry at affordable prices, paired with excellent customer service. Whether you're shopping for yourself or someone special, we’ve got the perfect piece to make you feel confident and stylish.</p>
  </div>
);


const Deliveries = () => (
  <div id="deliveries" className="container mt-3">
    <h2>Deliveries</h2>
    <p>
      <ul>
        <li>We offer shipping within South Africa.</li>
        <li>Estimated delivery times are 5 business days for domestic orders and 7 for international orders.</li>
        <li>Shipping fees are calculated at checkout. Free shipping is available for orders over $100.</li>
        <li>We are not responsible for lost, stolen, or delayed shipments after dispatch.</li>
      </ul>
    </p>
  </div>
);

const TermsAndConditions = () => (
  <div id="terms" className="container mt-3">
    <h2>T&Cs</h2>
    <p>
      <ul>
        <b>Introduction</b>
        <li>Dopamine99 operates this website to sell clothing and jewellery.</li>
        <li>By using our website, you accept these terms. If you do not agree, please refrain from using our services.</li>
      </ul>
      <ul>
        <b>Orders & Payment</b>
        <li>We accept the following payment methods for all transactions processed on our platform: Visa, Mastercard, and PayPal.</li>
        <li>Prices are in dollars and include applicable taxes unless stated otherwise.</li>
        <li>Orders are processed within 2 business days.</li>
        <li>We reserve the right to cancel orders due to pricing errors or stock unavailability.</li>
        <li>Once an order is placed, cancellations are only possible before shipping.</li>
      </ul>
      <ul> 
        <b>Product Descriptions & Pricing</b>
        <li>We strive to provide accurate product descriptions and images; however, colors may vary due to screen settings.</li>
        <li>Prices are subject to change without notice.</li>
        <li>We reserve the right to correct any pricing or typographical errors.</li>
      </ul>
      <ul>
        <b>Privacy Policy & Data Protection</b>
        <li>Your personal information is collected, stored, and used in compliance with applicable data protection laws (e.g., GDPR, POPIA).</li>
        <li>We do not sell or share your information with third parties without your consent.</li>
      </ul> 
      <ul>
        <b>Intellectual Property Rights</b>
        <li>All designs, images, text, and content on this website are the property of Dopamine99 and are protected by copyright and trademark laws.</li>
        <li>You may not reproduce, distribute, or resell any content without permission.</li>
      </ul>
      <ul>
        <b>Liability & Disclaimers</b>
        <li>We are not responsible for allergic reactions or sensitivities to our products. Please check product materials before purchasing.</li>
        <li>We do not guarantee uninterrupted or error-free website access.</li>
        <li>Our liability is limited to the amount paid for the product in question.</li>
      </ul>
      <ul>
        <b>User Conduct & Restrictions</b>
        <li>Users must not misuse the website (fraudulent activity, hacking, false reviews, etc.).</li>
        <li>We reserve the right to terminate accounts violating our policies.</li>
      </ul>
      <ul>
        <b>Dispute Resolution & Governing Law</b>
        <li>Disputes shall first be resolved through negotiation.</li>
        <li>If unresolved, disputes will be subject to arbitration in South Africa.</li>
        <li>These terms are governed by the laws of South Africa.</li>
      </ul>
    </p>
    </div>
); 

const ContactForm = () => {
  const [email, setEmail] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();

    // Simple email validation
    const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

    if (!emailRegex.test(email)) {
      alert("Please enter a valid email.");
      return;
    }

    // Replace this with an API call if needed
    alert("Thank you for subscribing!");
    setEmail(""); // Clear the input after submission
  };

  return (
    
  <div className="contact-section text-center p-4">
  <h3>For special deals:</h3>
  <form onSubmit={handleSubmit}>
    <div className="m-3">
      <label htmlFor="email" className="form-label">Email <i class="fa fa-envelope" aria-hidden="true"></i>:</label>
      <input
        type="email"
        className="form-control contact-input"
        id="email"
        placeholder="Enter your email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        required
      />
    </div>
    <button type="submit" className="btn btn-primary contact-btn">Submit</button>
  </form>
</div>
)
};

const Footer = () => {
  const [showFaq, setShowFaq] = useState(false);

  const toggleFaq = () => {
    setShowFaq((prev) => !prev);
  };

  useEffect(() => {
    // Initialize toast when the component mounts
    const toastTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="toast"]'));
    const toastList = toastTriggerList.map(function (toastTriggerEl) {
      return new window.bootstrap.Toast(toastTriggerEl);
    });
  }, []);

  return (
    <footer className="text-white text-center p-3 mt-5" style={{ backgroundColor: "#d065e6" }}>
      <p>&copy; 2025 Dopamine99. All rights reserved.</p>
      <p>
        Contact us on
        <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" className="text-white mx-2">
          <i className="fab fa-facebook fa-2x"></i>
        </a>
        <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" className="text-white mx-2">
          <i className="fab fa-twitter fa-2x"></i>
        </a>
        <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="text-white mx-2">
          <i className="fab fa-instagram fa-2x"></i>
        </a>
      </p>

      {/* FAQ Button with Toast */}
      <button
        onClick={toggleFaq}
        data-bs-toggle="toast"
        className="btn btn-light mt-3"
        style={{ backgroundColor: "#d468cb", color: "white" }}
      >
        FAQ
      </button>

      {/* Toast notification */}
      {showFaq && (
        <div className="toast-container position-fixed bottom-0 end-0 p-3">
          <div
            id="faqToast"
            className="toast show"
            role="alert"
            aria-live="assertive"
            aria-atomic="true"
            style={{ backgroundColor: "#ffffff", color: "#333" }}
          >
            <div
              className="toast-header"
              style={{
                backgroundColor: "#a968de",
                color: "#fff",
              }}
            >
              <strong className="me-auto">Frequently Asked Questions</strong>
              <button
                type="button"
                className="btn-close"
                data-bs-dismiss="toast"
                aria-label="Close"
                style={{ color: "#fff" }}
              ></button>
            </div>
            <div className="toast-body" style={{ backgroundColor: "#fb8dfc", color: "#ffffff"}}>
              <strong>What products do you sell?</strong>
              <p>We offer a wide range of clothing and jewelry, including shirts, dresses, accessories, and more.</p>
              <strong>How can I track my order?</strong>
              <p>You can track your order through the tracking link sent to your email once your order is shipped.</p>
              <strong>What is your return policy?</strong>
              <p>We offer a 30-day return policy for most items. Please check our Returns page for more details.</p>
              <strong>Do you offer international shipping?</strong>
              <p>Yes, we ship to several countries worldwide. Shipping fees and delivery times vary by location.</p>
              <strong>How can I contact customer service?</strong>
              <p>You can contact us via our support email or through our contact form on the website.</p>
            </div>
          </div>
        </div>
      )}
    </footer>
  );
};

const App = () => {
  return (
    <Provider store={store}>
      <Navbar />
      <ProductList />
      <Cart />
      <WishlistModal />
      <WishlistButton />
      <About />
      <Deliveries />
      <TermsAndConditions />
      <ContactForm />
      <Footer />
    </Provider>
  );
};

const domNode = document.getElementById("root")
const root = createRoot(domNode);
root.render(<App />)